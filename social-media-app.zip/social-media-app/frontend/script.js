const API_URL = "http://localhost:5000"; // backend server

// === User Session (temporary, until JWT/Auth added) ===
let currentUser = {
  id: 1, // assume logged-in user (replace with real login later)
  username: "samra"
};

// =============== POSTS ===============

// Add new post
async function addPost() {
  let postText = document.getElementById("postInput").value;
  if (postText.trim() === "") return;

  await fetch(`${API_URL}/posts/create`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId: currentUser.id, content: postText })
  });

  document.getElementById("postInput").value = "";
  loadPosts();
}

// Load posts from backend
async function loadPosts() {
  let feed = document.getElementById("feed");
  if (!feed) return;

  const res = await fetch(`${API_URL}/posts`);
  const posts = await res.json();

  feed.innerHTML = "";

  posts.forEach((post) => {
    let postDiv = document.createElement("div");
    postDiv.className = "post";

    postDiv.innerHTML = `
      <p><strong>@${post.username}</strong></p>
      <p>${post.content}</p>
      <button onclick="likePost(${post.id})">❤️ ${post.likes}</button>
      <input type="text" id="commentInput${post.id}" placeholder="Add a comment">
      <button onclick="addComment(${post.id})">Comment</button>
      <div class="comments" id="comments${post.id}"></div>
    `;
    feed.appendChild(postDiv);

    loadComments(post.id); // load comments under each post
  });
}

// Like post
async function likePost(postId) {
  await fetch(`${API_URL}/posts/like`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ postId })
  });
  loadPosts();
}

// Add comment
async function addComment(postId) {
  let input = document.getElementById(`commentInput${postId}`);
  let comment = input.value.trim();
  if (comment === "") return;

  await fetch(`${API_URL}/posts/comment`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ postId, userId: currentUser.id, comment })
  });

  input.value = "";
  loadComments(postId);
}

// Load comments for a post
async function loadComments(postId) {
  let container = document.getElementById(`comments${postId}`);
  if (!container) return;

  // Backend does not yet have GET /comments -> we will extend later
  // For now, just simulate empty or placeholder
  container.innerHTML = `<p style="color:gray;font-size:12px;">(Reload comments later when endpoint is added)</p>`;
}

// =============== PROFILE ===============

// Load user profile
async function loadProfile() {
  let username = document.getElementById("username");
  let followersCount = document.getElementById("followersCount");
  let myPosts = document.getElementById("myPosts");

  if (!username) return; // not on profile page

  const res = await fetch(`${API_URL}/users/${currentUser.id}`);
  const user = await res.json();

  username.innerText = user.username;
  followersCount.innerText = `Followers: ${user.followers}`;

  // Fetch posts of this user
  const postsRes = await fetch(`${API_URL}/posts`);
  const posts = await postsRes.json();

  myPosts.innerHTML = "";
  posts
    .filter(p => p.user_id === currentUser.id)
    .forEach(p => {
      let div = document.createElement("div");
      div.className = "post";
      div.innerHTML = `<p>${p.content}</p><p>❤️ ${p.likes}</p>`;
      myPosts.appendChild(div);
    });
}

// Follow system
async function toggleFollow() {
  let btn = document.getElementById("followBtn");
  let count = document.getElementById("followersCount");

  if (btn.innerText === "Follow") {
    await fetch(`${API_URL}/users/follow`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: currentUser.id })
    });
    btn.innerText = "Unfollow";
  } else {
    // (Optional: implement unfollow in backend later)
    btn.innerText = "Follow";
  }

  loadProfile();
}

// Auto-load data
window.onload = () => {
  loadPosts();
  loadProfile();
};
