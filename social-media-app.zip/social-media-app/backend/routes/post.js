// backend/routes/posts.js
const express = require("express");
const router = express.Router();
const db = require("../db");

// Create Post
router.post("/create", (req, res) => {
  const { userId, content } = req.body;
  db.query("INSERT INTO posts (user_id, content) VALUES (?, ?)", [userId, content], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Post created!" });
  });
});

// Get All Posts
router.get("/", (req, res) => {
  db.query("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.created_at DESC",
    (err, results) => {
      if (err) return res.status(500).json({ error: err });
      res.json(results);
    }
  );
});

// Like Post
router.post("/like", (req, res) => {
  const { postId } = req.body;
  db.query("UPDATE posts SET likes = likes + 1 WHERE id = ?", [postId], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Post liked!" });
  });
});

// Comment
router.post("/comment", (req, res) => {
  const { postId, userId, comment } = req.body;
  db.query("INSERT INTO comments (post_id, user_id, comment) VALUES (?, ?, ?)", [postId, userId, comment], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Comment added!" });
  });
});

module.exports = router;
