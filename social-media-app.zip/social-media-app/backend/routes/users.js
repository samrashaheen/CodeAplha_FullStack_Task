// backend/routes/users.js
const express = require("express");
const router = express.Router();
const db = require("../db");

// Get User Profile
router.get("/:id", (req, res) => {
  const { id } = req.params;
  db.query("SELECT id, username, email, followers FROM users WHERE id=?", [id], (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results[0]);
  });
});

// Follow User
router.post("/follow", (req, res) => {
  const { userId } = req.body;
  db.query("UPDATE users SET followers = followers + 1 WHERE id=?", [userId], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Followed user!" });
  });
});

module.exports = router;
