// ---------------------------
// Product Data (Demo)
// ---------------------------
const products = [
    { id: 1, name: "Smartphone", price: 299.99, image: "images/phone.jpg", description: "Latest model smartphone with high resolution display." },
    { id: 2, name: "Laptop", price: 799.99, image: "images/laptop.jpg", description: "High performance laptop for work and gaming." },
    { id: 3, name: "Headphones", price: 49.99, image: "images/headphones.jpg", description: "Noise-cancelling over-ear headphones." },
    { id: 4, name: "Smartwatch", price: 149.99, image: "images/watch.jpg", description: "Fitness tracking smartwatch with long battery life." }
];

// ---------------------------
// Utility Functions
// ---------------------------
function getCart() {
    return JSON.parse(localStorage.getItem("cart")) || [];
}

function saveCart(cart) {
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCartCount();
}

function updateCartCount() {
    const cartCountEl = document.getElementById("cart-count");
    if (cartCountEl) {
        const cart = getCart();
        cartCountEl.textContent = cart.reduce((total, item) => total + item.quantity, 0);
    }
}

// ---------------------------
// Load Products on index.html
// ---------------------------
if (document.getElementById("product-list")) {
    const productList = document.getElementById("product-list");
    products.forEach(product => {
        const div = document.createElement("div");
        div.classList.add("product-card");
        div.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>$${product.price.toFixed(2)}</p>
            <a href="product.html?id=${product.id}" class="btn">View Details</a>
        `;
        productList.appendChild(div);
    });
}

// ---------------------------
// Product Details Page
// ---------------------------
if (document.getElementById("product-details")) {
    const params = new URLSearchParams(window.location.search);
    const productId = parseInt(params.get("id"));
    const product = products.find(p => p.id === productId);

    if (product) {
        const details = document.getElementById("product-details");
        details.innerHTML = `
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <div>
                <h2>${product.name}</h2>
                <p>${product.description}</p>
                <h3>Price: $${product.price.toFixed(2)}</h3>
                <button class="btn" id="add-to-cart">Add to Cart</button>
            </div>
        `;

        document.getElementById("add-to-cart").addEventListener("click", () => {
            let cart = getCart();
            const existing = cart.find(item => item.id === product.id);
            if (existing) {
                existing.quantity++;
            } else {
                cart.push({ ...product, quantity: 1 });
            }
            saveCart(cart);
            alert("Product added to cart!");
        });
    }
}

// ---------------------------
// Cart Page
// ---------------------------
if (document.getElementById("cart-items")) {
    function renderCart() {
        const cartItemsEl = document.getElementById("cart-items");
        const cart = getCart();
        cartItemsEl.innerHTML = "";

        if (cart.length === 0) {
            cartItemsEl.innerHTML = "<p>Your cart is empty.</p>";
            document.getElementById("cart-total").textContent = "0.00";
            return;
        }

        let total = 0;
        cart.forEach(item => {
            total += item.price * item.quantity;
            const div = document.createElement("div");
            div.classList.add("cart-item");
            div.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div>
                    <h4>${item.name}</h4>
                    <p>$${item.price.toFixed(2)} x ${item.quantity}</p>
                    <button class="btn-remove" data-id="${item.id}">Remove</button>
                </div>
            `;
            cartItemsEl.appendChild(div);
        });

        document.getElementById("cart-total").textContent = total.toFixed(2);

        document.querySelectorAll(".btn-remove").forEach(btn => {
            btn.addEventListener("click", () => {
                const id = parseInt(btn.getAttribute("data-id"));
                let cart = getCart().filter(item => item.id !== id);
                saveCart(cart);
                renderCart();
            });
        });
    }

    renderCart();
}

// ---------------------------
// Checkout Page
// ---------------------------
if (document.getElementById("checkout-form")) {
    document.getElementById("checkout-form").addEventListener("submit", (e) => {
        e.preventDefault();
        alert("Order placed successfully!");
        localStorage.removeItem("cart");
        window.location.href = "index.html";
    });
}

// ---------------------------
// Registration
// ---------------------------
if (document.getElementById("register-form")) {
    document.getElementById("register-form").addEventListener("submit", (e) => {
        e.preventDefault();
        const fullname = document.getElementById("fullname").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        const confirmPassword = document.getElementById("confirm-password").value;

        if (password !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }

        const user = { fullname, email, password };
        localStorage.setItem("user", JSON.stringify(user));
        alert("Registration successful! Please login.");
        window.location.href = "login.html";
    });
}

// ---------------------------
// Login
// ---------------------------
if (document.getElementById("login-form")) {
    document.getElementById("login-form").addEventListener("submit", (e) => {
        e.preventDefault();
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        const storedUser = JSON.parse(localStorage.getItem("user"));
        if (storedUser && storedUser.email === email && storedUser.password === password) {
            alert("Login successful!");
            window.location.href = "index.html";
        } else {
            alert("Invalid email or password!");
        }
    });
}

// ---------------------------
// Update cart count on all pages
// ---------------------------
updateCartCount();
