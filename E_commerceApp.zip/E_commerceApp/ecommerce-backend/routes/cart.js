const express = require("express");
const db = require("../db");

const router = express.Router();

// Get user's cart
router.get("/:userId", (req, res) => {
    const { userId } = req.params;
    db.query("SELECT * FROM cart WHERE user_id = ?", [userId], (err, results) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json(results);
    });
});

// Add to cart
router.post("/", (req, res) => {
    const { userId, productId, quantity } = req.body;
    db.query("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)",
        [userId, productId, quantity],
        (err) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.status(201).json({ message: "Added to cart" });
        }
    );
});

// Remove from cart
router.delete("/:id", (req, res) => {
    const { id } = req.params;
    db.query("DELETE FROM cart WHERE id = ?", [id], (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json({ message: "Removed from cart" });
    });
});

module.exports = router;
