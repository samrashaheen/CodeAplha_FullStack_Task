const express = require("express");
const db = require("../db");

const router = express.Router();

// Get all products
router.get("/", (req, res) => {
    db.query("SELECT * FROM products", (err, results) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json(results);
    });
});

// Add new product
router.post("/", (req, res) => {
    const { name, description, price, image } = req.body;
    if (!name || !description || !price || !image) {
        return res.status(400).json({ message: "All fields are required" });
    }
    db.query("INSERT INTO products (name, description, price, image) VALUES (?, ?, ?, ?)",
        [name, description, price, image],
        (err) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.status(201).json({ message: "Product added" });
        }
    );
});

module.exports = router;
