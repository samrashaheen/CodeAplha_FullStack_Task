const express = require("express");
const db = require("../db");

const router = express.Router();

// Place an order
router.post("/", (req, res) => {
    const { userId, totalPrice, address } = req.body;
    db.query("INSERT INTO orders (user_id, total_price, address) VALUES (?, ?, ?)",
        [userId, totalPrice, address],
        (err, result) => {
            if (err) return res.status(500).json({ message: "Database error" });

            // Empty the cart after placing order
            db.query("DELETE FROM cart WHERE user_id = ?", [userId], (err2) => {
                if (err2) return res.status(500).json({ message: "Order placed but cart not cleared" });
                res.status(201).json({ message: "Order placed successfully" });
            });
        }
    );
});

// Get all orders for a user
router.get("/:userId", (req, res) => {
    const { userId } = req.params;
    db.query("SELECT * FROM orders WHERE user_id = ?", [userId], (err, results) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json(results);
    });
});

module.exports = router;
